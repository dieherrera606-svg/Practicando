
package agenciaparanormal122;


public interface Informable {
    
    String generarInforme();
    
}
