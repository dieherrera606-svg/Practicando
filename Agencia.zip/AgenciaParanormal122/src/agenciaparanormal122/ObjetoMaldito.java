
package agenciaparanormal122;


public class ObjetoMaldito extends CasoParanormal implements Informable{

    private String material;

    public ObjetoMaldito(String nombre, String investigador, NivelRiesgo riesgo , String material) {
        super(nombre, investigador, riesgo);
        validarMaterial(material);
        this.material = material;
    }
    
    private static void validarMaterial(String material){
        if(material == null || material.isBlank()){
            throw new IllegalArgumentException("Material Invalido");
        }
    }

    public String getMaterial() {
        return material;
    }
    
    
    
    @Override
    public String generarInforme() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
