
package agenciaparanormal122;


public class Aparicion extends CasoParanormal implements Investigable{
    
    private String horarioFrecuente;

    public Aparicion(String nombre, String investigador, NivelRiesgo riesgo , String horarioFrecuente) {
        super(nombre, investigador, riesgo);
        validarHorario(horarioFrecuente);
        this.horarioFrecuente = horarioFrecuente;
    }
    
    private static void validarHorario(String horario){
        if(horario == null || horario.isBlank()){
            throw new IllegalArgumentException("Zona Horaria Invalida");
        }
    }

    public String getHorarioFrecuente() {
        return horarioFrecuente;
    }
    
    @Override
    public String investigar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
