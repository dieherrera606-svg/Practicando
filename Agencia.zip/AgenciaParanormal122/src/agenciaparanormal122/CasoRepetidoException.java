
package agenciaparanormal122;


public class CasoRepetidoException extends RuntimeException{
    
    private static final String mensaje = "El caso ya fue registrado";

    public CasoRepetidoException() {
        this(mensaje);
    }

    public CasoRepetidoException(String mensaje) {
        super(mensaje);
    }
    
    
    
}

