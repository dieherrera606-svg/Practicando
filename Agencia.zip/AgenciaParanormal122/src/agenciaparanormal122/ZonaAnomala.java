
package agenciaparanormal122;


public class ZonaAnomala extends CasoParanormal implements Investigable , Informable{
    
    private int radio;

    public ZonaAnomala(String nombre, String investigador, NivelRiesgo riesgo , int radio) {
        super(nombre, investigador, riesgo);
        this.radio = radio;
    }
    
    private static void validarRadio(int radio){
        if(radio <= 0){
            throw new IllegalArgumentException("Radio Invalida");
        }
    }

    public int getRadio() {
        return radio;
    }
    
    
    
    @Override
    public String investigar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generarInforme() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
