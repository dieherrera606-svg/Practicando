
package agenciaparanormal122;


public enum NivelRiesgo {
    
    BAJO,
    MODERADO,
    CRITICO
    
}
