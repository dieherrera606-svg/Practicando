
package agenciaparanormal122;

import java.util.Objects;


public abstract class CasoParanormal {
    
    private String nombre;
    private String investigador;
    private NivelRiesgo riesgo;

    public CasoParanormal(String nombre, String investigador, NivelRiesgo riesgo) {
        validarString(nombre);
        validarString(investigador);
        validarRiesgo(riesgo);
        
        this.nombre = nombre;
        this.investigador = investigador;
        this.riesgo = riesgo;
    }
    
    private static void validarString(String cadena){
        if(cadena == null || cadena.isBlank()){
            throw new IllegalArgumentException("Nombre Invalido o en Blanco");
        }
    }
    private static void validarRiesgo(NivelRiesgo riesgo){
        if(riesgo == null){
            throw new IllegalArgumentException("ERROR.Riesgo Invalido");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getInvestigador() {
        return investigador;
    }

    public NivelRiesgo getRiesgo() {
        return riesgo;
    }

    @Override
    public String toString() {
        return "-Caso Paranormal --> Nombre : " + nombre + " Investigador : " + investigador + "Nivel De Riesgo : " + riesgo;
    }
    
    public abstract String getDescripcion();

    @Override
    public int hashCode() {
       return 1;
    }

    @Override
    public boolean equals(Object obj) {
        return false;
    }
    
    
    
}
