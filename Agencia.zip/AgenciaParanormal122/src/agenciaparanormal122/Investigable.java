
package agenciaparanormal122;


public interface Investigable {
    
    String investigar();
    
}
