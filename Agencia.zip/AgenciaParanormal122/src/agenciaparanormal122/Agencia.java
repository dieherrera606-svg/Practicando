
package agenciaparanormal122;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class Agencia {
    
    private String nombre;
    private List<CasoParanormal> casos ;

    public Agencia(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        casos = new ArrayList<>();
        
    }
    
    private static void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("Nombre Invalido o en Blanco");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public List<CasoParanormal> getCasos() {
        return new ArrayList<>(casos);
    }
    
    private void validarCasoRepetido(CasoParanormal caso){
        if(casos.contains(caso)){
            throw new CasoRepetidoException();
        }
    }
    
    public void agregarCaso(CasoParanormal caso){
        Objects.requireNonNull(caso);
        validarCasoRepetido(caso);
        casos.add(caso);
    }
    
}
